#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/socket.h>
#include <errno.h>
#include <netdb.h>
#include <arpa/inet.h>

//name -> IP
void getIPInfor(char *hostname){
	struct hostent *host;
	struct in_addr **addr_list;
	int i;
	if ((host = gethostbyname(hostname)) == NULL){
		printf("Not found information\n");
		return ;
	}
	addr_list = (struct in_addr **) host->h_addr_list;
	printf("Official IP: %s\n",inet_ntoa(*addr_list[0]));
	if (addr_list[1] != NULL){
		printf("Alias IP:\n");
		for(i=1;addr_list[i] != NULL;i++){
				printf("%s \n",inet_ntoa(*addr_list[i]));
			}
			printf("\n");
	}
}

//IP->Name
void getNameInfor(char *ip){
	struct in_addr addr;
	struct hostent *host;
	
	inet_aton(ip,&addr);
	
	host = gethostbyaddr(((const char*)&addr),sizeof(addr), AF_INET);

	if(host == NULL){
		printf("Not found information\n");
		return;
	}	
	else {
		printf("Official Name: %s\n",host->h_name);
		
		char **pAlias = host->h_aliases;
		if (*pAlias != 0){
			printf("Alias Name: \n");
			for (pAlias = host->h_aliases; *pAlias != 0; pAlias++) {
				printf("\t%s\n", *pAlias);
			}
		}
	}
}

int main(int argc, char *argv[])
{
	char *input;

  if (argc != 2) {
    printf("Syntax is './resolver parameter'\n");
    return 0;
  }

  input = argv[1];

  if (isalpha(*input)) {       
    getIPInfor(input);
  } else {
    getNameInfor(input);       
  }

	return 0;
}
