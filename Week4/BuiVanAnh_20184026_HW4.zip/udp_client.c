/*UDP Echo Client*/
#include <stdio.h>          /* These are the usual header files */
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>

// #define SERV_PORT 5550
// #define SERV_IP "127.0.0.1"
#define BUFF_SIZE 1024

int main(int argc, char* argv[]){
	int client_sock;
	char buff[BUFF_SIZE];
	struct sockaddr_in server_addr;
	int bytes_sent,bytes_received, sin_size;

	//check parameter
	if (argc != 3){
		printf("Invalid parameter!!!\n");
		exit(0);
	}
	
	//Step 1: Construct a UDP socket
	if ((client_sock=socket(AF_INET, SOCK_DGRAM, 0)) < 0 ){  /* calls socket() */
		perror("\nError: Failed to create socket\n");
		exit(0);
	}

	//Step 2: Define the address of the server
	bzero(&server_addr, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(atoi(argv[2]));
	server_addr.sin_addr.s_addr = inet_addr(argv[1]);
	
	//Step 3: Communicate with server
	char number[50];
	while (1){
		printf("\nInsert string to send:");
		memset(buff,'\0',(strlen(buff)+1));
		memset(number,'\0',(strlen(number)+1));
		fgets(buff, BUFF_SIZE, stdin);

		if(buff[0]=='\n') break;
		buff[strlen(buff)-1] = '\0';

		sin_size = sizeof(struct sockaddr);
			
		bytes_sent = sendto(client_sock, (char *)buff, strlen(buff), MSG_CONFIRM, (struct sockaddr *) &server_addr, sizeof(server_addr));
		if(bytes_sent < 0){
			perror("Error");
			close(client_sock);
			return 0;
		}
		printf("Successful to send to server.\n");

		bytes_received = recvfrom(client_sock, (char *)buff, BUFF_SIZE, MSG_WAITALL, (struct sockaddr *) &server_addr, &sin_size);
		if(bytes_received < 0){
			perror("Error");
			close(client_sock);
			return 0;
		}
		buff[bytes_received] = '\0';

		bytes_received = recvfrom(client_sock, (char *)number, sizeof(number), MSG_WAITALL, (struct sockaddr *) &server_addr, &sin_size);
		if(bytes_received < 0){
			perror("Error");
			close(client_sock);
			return 0;
		}
		number[bytes_received] = '\0';


		printf("Reply from server: \n%s\n%s",number, buff);
	}

	
		
	close(client_sock);
	return 0;
}
