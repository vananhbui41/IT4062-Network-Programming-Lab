/*UDP Echo Server*/
#include <stdio.h>          /* These are the usual header files */
#include <sys/types.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>

// #define PORT 5550  /* Port that will be opened */ 
#define BUFF_SIZE 1024

int separateLetNum(char *, char *, char *);

int main(int argc, char* argv[])
{ 
	int server_sock; /* file descriptors */
	char buff[BUFF_SIZE];
	int bytes_sent, bytes_received;
	struct sockaddr_in server; /* server's address information */
	struct sockaddr_in client; /* client's address information */
	int sin_size;


	// Check parameter 
	if (argc !=2){
		printf("Invalid parameter\n");
		exit(0);
	}
	//Step 1: Construct a UDP socket
	if ((server_sock=socket(AF_INET, SOCK_DGRAM, 0)) < 0 ){  /* calls socket() */
		perror("\nError: Failed to create socket\n");
		exit(0);
	} 
	printf("Success to connect to server.\n");

	memset(&server, 0, sizeof(server));
	memset(&client, 0, sizeof(client));
	
	//Step 2: Bind address to socket
	server.sin_family = AF_INET;     // IPv4
	server.sin_port = htons((atoi(argv[1])));   /* Remember htons() from "Conversions" section? =) */
	server.sin_addr.s_addr = INADDR_ANY;  /* INADDR_ANY puts your IP address automatically */   
	bzero(&(server.sin_zero),8); /* zero the rest of the structure */

  
	if(bind(server_sock,(struct sockaddr*)&server,sizeof(server)) < 0){ /* calls bind() */
		perror("\nError: bind Failed");
		exit(0);
	}     
	
	//Step 3: Communicate with clients
	char result[100];
	char number[50];
	while(1){
		memset(result,'\0',100);
		memset(result,'\0',50);

		sin_size = sizeof(struct sockaddr_in);
    		
		bytes_received = recvfrom(server_sock, (char *)buff, BUFF_SIZE, MSG_WAITALL, (struct sockaddr *) &client, &sin_size);
		buff[bytes_received] = '\0';

		int x = separateLetNum(buff,result,number);

		if(x==1){
			printf("Error: Invalid characters.\n");
			strcpy(result,"Error: Invalid character");
		}	
    
		sendto(server_sock,(char *)result, strlen(result), MSG_CONFIRM, (const struct sockaddr *)&client,sizeof(client));
		sendto(server_sock,(char *)number, strlen(number), MSG_CONFIRM, (const struct sockaddr *)&client,sizeof(client));

	close(server_sock);
	return 0;
	}
}

int separateLetNum(char *buff, char *result, char *number){
  int l1 = strlen(result);
    int l2 = strlen(number);
  for(int i=0;i<strlen(buff);i++){
    int dec = (int)buff[i];
    if(dec>=48&&dec<=57) {
      *(number+l2)=buff[i];
      l2++;
    }else if((dec>=65&&dec<=90)||(dec>=97&&dec<=122)){
      *(result+l1)=buff[i];
      l1++;
    }else return 1;
  }
  return 0;
}